function somar() {
    let n1 = Number(window.prompt('Digite um número:'))
    let n2 = Number(window.prompt('Digite outro número:'))
    let n3 = Number(window.prompt('Digite outro número:'))

    let res = document.querySelector('section#res')
    res.innerHTML = `<span> A soma entre ${n1} e ${n2} dividida por ${n3} é igual a ${(n1+n2)/n3}<\span>`
}
function divisao() {
    let n5 = Number(window.prompt('Digite a distancia em KM:'))
    let n6 = Number(window.prompt('Digite um número que esteja em KM/H:'))

    let res1 = document.querySelector('section#res')
    res.innerHTML = `<span> O tempo para chegar é ${n5/n6} horas<\span>`
}